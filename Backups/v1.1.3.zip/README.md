# TRL - RespawnHeim - [ZA]

Welcome to **TRL - RespawnHeim - [ZA]**, a modded Valheim experience designed for adventurers, warriors, and builders alike. This modpack enhances every aspect of Valheim, from combat and exploration to crafting and settlement building. Hosted on the **The Respawn Lounge** Discord server, this world brings together players who want a richer, more immersive Viking experience.

## Features

### ⚔️ Combat Enhancements

- **Therzie's kindly & Armory** – Expands your arsenal with new weapons and armor.
- **Better Archery** – Improves bow mechanics for a more satisfying ranged combat experience.
- **Passive Powers, Evasion, Tenacity, and Vitality** – Adds skills that improve mobility, durability, and survival in battle.
- **Resurrection** – Revive fallen teammates and keep the fight going.

### 🌱 Farming, Crafting & Survival

- **Plant Everything & Plant Easily** – Grow crops, herbs, and more to sustain your Viking clan.
- **Farming, Cooking & Ranching** – Enhances food production and animal husbandry.
- **Adventure Backpacks & PackHorse** – Manage your inventory more efficiently on long journeys.
- **HoneyPlus** – Expands beekeeping and honey production.

### 🏠 Building & Settlement Expansion

- **Advanced Terrain Modifiers** – Shape the land to your needs.
- **Smoothbrain-Building** – Adds new construction tools and improvements.
- **Boat Additions** – Expand your naval capabilities for better exploration.
- **AzuWorkbenchTweaks** – Enhances crafting station mechanics.
- **Hide To Scrap** – Adds scrap functionality for hide materials.
- **Improved Build HUD** – Enhances the building interface for better usability.

### 🌍 Exploration & Adventure

- **Sailing & Exploration** – Enhances biome discovery and adventure.
- **Venture Location Reset** – Respawns key locations for replayability.
- **Longer Days** – Extends daylight hours for more adventuring.
- **Where You At** – Helps locate players easily.

### ⚙️ Utility & Quality of Life

- **Quick Stack, Store, Sort, Trash & Restock** – Improves inventory management.
- **FastLink** – Enhances server connectivity. By default, our dedicated Valheim server is included as one of the default FastLink links—feel free to add more for your own server.
- **Resource Unload Optimizer** – Optimizes resource management.
- **Darwin Awards** – Adds an amusing twist to player deaths.
- **Network** – Improves server and client interactions.

### 🔐 Multiplayer & Server Management

- **Server Characters & AzuAntiCheat** – Maintains fair play in multiplayer sessions.
- **Ward Is Love** – Protects your base and prevents griefing.
- **Protect Your Seed** – Safeguards your world from unintended changes.
- **Discord Connector** – Enables server integration with Discord.

## Installation

1. Download and install **Valheim** via Steam.
2. Install **Thunderstore Mod Manager** (or use **r2modman** for easy mod management).
3. Download **TRL - RespawnHeim - ZA** from the [Thunderstore page] (if applicable).
4. Launch Valheim through the mod manager and join the **The Respawn Lounge** server.

## How to Join

- Server details and access are available in the **⚔️ RespawnHeim - Valheim Server** channel on the **The Respawn Lounge** Discord.
- Ensure all mods are installed and up to date to avoid compatibility issues.

## Community & Support

This modpack can be used for **both personal gameplay** and for joining our **dedicated Valheim server**. While the modpack is freely available, official support and discussions happen in our Discord community.

- Join our Discord server to find party members, discuss strategies, and report any issues.
- The **TRL - RespawnHeim - ZA** Valheim server is hosted in **South Africa**, so players outside the region may experience higher latency.

[Join the Discord](https://discord.gg/kCrFgqavxD)

## Changelog

### 1.1.3
- Added **Improved Build HUD** to enhance building interface usability.
- Included **FastLink** by default with our dedicated server pre-configured.
- Various mod updates for stability and performance.

### 1.1.2
- Integrated **Therzie's Warfare & Armory** for expanded weapons and armor.
- Added **Advanced Terrain Modifiers** for better landscape shaping.
- Included **Passive Powers, Evasion, Tenacity, and Vitality** for combat improvements.

### 1.1.1
- Initial release of **TRL - RespawnHeim - ZA** modpack.
- Focused on combat, exploration, building, and survival improvements.

## Credits

Special thanks to all the mod creators who made this enhanced Valheim experience possible. If you enjoy their work, consider supporting them on their respective platforms.

---

Welcome to **TRL - RespawnHeim - ZA** – where the adventure never ends! ⚔️🔥

